<?php
 //$shippedOptions= get_post_meta( $_GET['post'], 'shipping_options', true );
//$order_data = new WC_Order($order_id);
//$order->get_shipping_methods(); .
 //$shippedOptions=$order->get_shipping_method();
//require_once("wp-load.php");
//$order_idd= $_GET['post'];
//$order_data = new WC_Order($order_idd);

add_action( 'woocommerce_admin_order_data_after_billing_address', 'fluidcast_order_detailspage_npayg', 10, 1 );

function fluidcast_order_detailspage_npayg($order){
$order->get_shipping_methods(); 
  $shippedOptions=trim($order->get_shipping_method());
echo '<p><strong>'.__('Shipping Option').':</strong> ' .  $shippedOptions . '</p>';
if(trim($shippedOptions)=="In Person")
{
	echo "<style>.debitway_paygo_shipping_postbox{display:none;} .order_data_column_container > .order_data_column:last-child { display:none !important; }</style>";
}

}


	add_action( 'woocommerce_admin_order_data_after_order_details', 'fluidcast_editable_order_meta_general_npaygo' );


 //Action cannot be completed   --error
function fluidcast_editable_order_meta_general_npaygo( $order ){ 

	$active_methods   = array();
    $shipping_methods = WC()->shipping->get_shipping_methods();
    foreach ( $shipping_methods as $id => $shipping_method ) {
      if ( isset( $shipping_method->enabled ) && 'yes' === $shipping_method->enabled ) {
        $active_methods[ $id ] = array(
          'title'      => $shipping_method->title,
          'tax_status' => $shipping_method->tax_status,
        );
      }
    }
//print_r( $active_methods);

  $customer_note = $order->get_customer_note();

$shippingAddress.="shipping_first_name:".$order->shipping_first_name;
$shippingAddress.="|shipping_last_name:".$order->shipping_last_name;
$shippingAddress.="|shipping_company:".$order->shipping_company;
$shippingAddress.="|shipping_address_1:".$order->shipping_address_1;
$shippingAddress.="|shipping_address_2:".$order->shipping_address_2;
$shippingAddress.="|shipping_city:".$order->shipping_city;
$shippingAddress.="|shipping_state:".$order->shipping_state;
$shippingAddress.="|shipping_postcode:".$order->shipping_postcode;
$shippingAddress.="|shipping_country:".$order->shipping_country;
$shippingAddress.="|Order_id :".$_GET['post'];
$shippingAddress.="|currenturl :".(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$order->get_shipping_methods();
 $shipping_options= $order->get_shipping_method();
$shippingAddress.="|Shipping_options :".$shipping_options;
$shippingAddress.="| :".md5($order->id);

if( $customer_note!=""){
		$commentsDebitway=urlencode($customer_note)."|".$shippingAddress;
}else{

$commentsDebitway=$shippingAddress;
}

 add_action('admin_head', 'my_fluidcastadmin_head');
function my_fluidcastadmin_head() {?>
<style>
    #Fluidcast_shipping_options_field {clear:both !important;}
    </style>
<?php }

 ?>
 
<div class="clear"></div>
	<div class="debitway_paygo_shipping_postbox" style="border:2px solid #f90;overflow:hidden;margin-top:10px;">
		<div style="padding:10px;">
			<h1>CPTSecure Shipping Post</h1>

		<div id="notification_post"></div>
		<div id="notification_postback"></div>
		<div class="address" >
			
				<div class="form_debitway">
					<?php  //$comments= ?>

					
						<p class="form-field form-field-wide"><label for="order_date">Shipping type:</label>
							<select name="shipping_method" id="shipping_method">
								<?php foreach($active_methods as $key => $shipping_methods){
								if($key!="local_pickup") {?>
								<option value="<?php echo $key;?>"> <?php echo ucfirst(str_replace("_"," ",$key));?></option>

								<?php } } ?>

							</select>	
						</p>

						<p class="form-field form-field-wide"><label for="order_date">Tracking Number:</label>
							<input type="text"  name="tracking_number" id="tracking_number">
						</p>

						<p class="form-field form-field-wide"><label for="order_date">Comments: &nbsp;(minimum: 300 character)</label>
							<span id='remainingC'></span>

							<textarea type="text" name="comments" id="comments" class="input-text" cols="20" rows="10"><?php echo 	$commentsDebitway;?></textarea>
						</p>

						<p class="form-field form-field-wide" style="margin-bottom:20px;">
							<input type="hidden" name="session" id="session" value="<?php echo $_GET['post'];?>"/>
							<input type="hidden" name="date_order" id="date_order" value="<?php echo date("Y-m-d");?>"/>
							<a  class="button save_order button-primary"  id="send_shipping_post">Send</a>
							
						</p>
						 
					

					</div>	

				</div>	
			
			</div>
		</div>
<script>

jQuery(document).ready(function() {
  var len = 0;
  var maxchar = 300;

var lengt=jQuery( '#comments' ).val().length;
   jQuery( "#remainingC" ).html( "Total Character: " +(  lengt ) );


  jQuery( '#comments' ).keyup(function(){
    len = this.value.length
   /* if(len > maxchar){
        return false;
    }*/
     jQuery( "#remainingC" ).html( "Total characters: " +( len ) );
    /*else if (len > 0) {
        jQuery( "#remainingC" ).html( "Remaining characters: " +( maxchar - len ) );
    }
    else {
        jQuery( "#remainingC" ).html( "Remaining characters: " +( maxchar ) );
    }*/
  })
});


jQuery(function(){
		//url: 'https://payments.fintechwerx.com/order/shipping.php?session=211&shipping_method=ups&tracking_number=1&date=2018-11-28&comments=test%20testtesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttest',	
			
			jQuery("#send_shipping_post").click(function(){
				
				
				jQuery("#notification_post").html("");
				
				var tracking_number = jQuery("#tracking_number").val();
				var session = jQuery("#session").val();
				var comments = jQuery("#comments").val();
				var shipping_method = jQuery("#shipping_method").val();
				var date_order = jQuery("#date_order").val();

				//alert(session); return false;
				
				jQuery.ajax({
					type: 'GET',
					url: 'https://payments.fintechwerx.com/order/shipping.php',
					//url: 'http://localhost/wp_latest/wp-content/plugins/paygo/testajax.php',
					data: ({
					'session':session,
					'shipping_method':shipping_method,
					'tracking_number' : tracking_number,
					'date':date_order,
					'comments' : comments,

					}),

					success: function(response)
					{	//$("#yesNoConform").html(response);
						response = jQuery.trim(response);
						if(response == '1')
						{
							//jQuery("#yes_no").hide();
							jQuery("#notification_post").html("<span class='success' style='color:red;'><strong>Successfully completed.</strong></span>");
							jQuery("#notification_postback").load("<?php  echo plugin_dir_url( __FILE__ );?>debitway_postback_ifsuccess.php?session=<?php echo $_GET['post'];?>");

						}
						else
						{
							jQuery("#notification_post").html('<span class="success" style="color:red;"><strong>Action cannot be completed.</strong></span>');
							
							}
						}
				});
				
			})
			
			
		})

</script>


<?php } 


// hide shiiping options if select shipping option toIn persion
add_action( 'woocommerce_after_checkout_form', 'fluidcast_disable_shipping_local_pickup_npaygo' );
 
function fluidcast_disable_shipping_local_pickup_npaygo( $available_gateways ) {
global $woocommerce;
 
// Part 1: Hide shipping based on the static choice @ Cart
// Note: "#customer_details .col-2" strictly depends on your theme
 
$chosen_methods = WC()->session->get( 'chosen_shipping_methods' );
$chosen_shipping_no_ajax = $chosen_methods[0];
if ( 0 === strpos( $chosen_shipping_no_ajax, 'local_pickup' ) ) {
 
?><style>#Fluidcast_shipping_options_field {clear:both !important;}</style>
<script type="text/javascript">
 
    jQuery('.woocommerce-shipping-fields').fadeOut();
 
</script>
<?php
     
} 
 
// Part 2: Hide shipping based on the dynamic choice @ Checkout
// Note: "#customer_details .col-2" strictly depends on your theme
 
?>
<script type="text/javascript">
                jQuery('form.checkout').on('change','input[name^="shipping_method"]',function() {
    var val = jQuery( this ).val();
    if (val.match("^local_pickup")) {
                jQuery('.woocommerce-shipping-fields').fadeOut();
        } else {
        jQuery('.woocommerce-shipping-fields').fadeIn();
    }
});
 
</script>
<?php
 
}?>