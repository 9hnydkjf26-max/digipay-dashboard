<?php
require_once("../../../../wp-load.php");
$order_id=@$_REQUEST['session'];
$order = new WC_Order( $order_id );

//$order->get_shipping_methods();
//echo $shipping_options= $order->get_shipping_method();

$order->update_status( 'completed' );
?>