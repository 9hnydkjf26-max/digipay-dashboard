<?php
/**
 * Digipay Diagnostics & Health Reporting v2
 * 
 * Comprehensive diagnostics including:
 * - SSL/HTTPS check
 * - cURL availability
 * - Firewall/connectivity detection
 * - Postback tracking
 * 
 * Add this code to woocommerce-gateway-paygo.php
 * OR include it as a separate file: require_once('digipay-diagnostics.php');
 */

// ============================================================
// ISSUE CODES
// ============================================================
define( 'DIGIPAY_ISSUE_NO_SSL', 'NO_SSL' );
define( 'DIGIPAY_ISSUE_NO_CURL', 'NO_CURL' );
define( 'DIGIPAY_ISSUE_CURL_OLD', 'CURL_OLD' );
define( 'DIGIPAY_ISSUE_NO_OPENSSL', 'NO_OPENSSL' );
define( 'DIGIPAY_ISSUE_FIREWALL', 'FIREWALL' );
define( 'DIGIPAY_ISSUE_API_TIMEOUT', 'API_TIMEOUT' );
define( 'DIGIPAY_ISSUE_API_ERROR', 'API_ERROR' );
define( 'DIGIPAY_ISSUE_POSTBACK_FAIL', 'POSTBACK_FAIL' );

// ============================================================
// ENVIRONMENT DIAGNOSTICS
// ============================================================

/**
 * Run all diagnostic checks and return results
 */
function digipay_run_diagnostics() {
    $results = array(
        'has_ssl' => false,
        'has_curl' => false,
        'curl_version' => null,
        'openssl_version' => null,
        'can_reach_api' => false,
        'firewall_issue' => false,
        'issues' => array(),
        'details' => array(),
        'server_software' => isset( $_SERVER['SERVER_SOFTWARE'] ) ? $_SERVER['SERVER_SOFTWARE'] : 'Unknown'
    );
    
    // Check 1: SSL/HTTPS
    $ssl_check = digipay_check_ssl();
    $results['has_ssl'] = $ssl_check['ok'];
    if ( ! $ssl_check['ok'] ) {
        $results['issues'][] = DIGIPAY_ISSUE_NO_SSL;
        $results['details'][] = $ssl_check['message'];
    }
    
    // Check 2: cURL
    $curl_check = digipay_check_curl();
    $results['has_curl'] = $curl_check['ok'];
    $results['curl_version'] = $curl_check['version'];
    if ( ! $curl_check['ok'] ) {
        $results['issues'][] = $curl_check['issue_code'];
        $results['details'][] = $curl_check['message'];
    }
    
    // Check 3: OpenSSL
    $openssl_check = digipay_check_openssl();
    $results['openssl_version'] = $openssl_check['version'];
    if ( ! $openssl_check['ok'] ) {
        $results['issues'][] = DIGIPAY_ISSUE_NO_OPENSSL;
        $results['details'][] = $openssl_check['message'];
    }
    
    // Check 4: Outbound connectivity / Firewall
    $connectivity_check = digipay_check_connectivity();
    $results['can_reach_api'] = $connectivity_check['ok'];
    $results['firewall_issue'] = $connectivity_check['firewall_suspected'];
    if ( ! $connectivity_check['ok'] ) {
        $results['issues'][] = $connectivity_check['issue_code'];
        $results['details'][] = $connectivity_check['message'];
    }
    
    // Check 5: Postback status
    $postback_stats = digipay_get_postback_stats();
    if ( $postback_stats['error_count'] > 0 && $postback_stats['success_count'] == 0 ) {
        $results['issues'][] = DIGIPAY_ISSUE_POSTBACK_FAIL;
        $results['details'][] = 'All postback attempts have failed. Last error: ' . $postback_stats['last_error_message'];
    }
    
    // Store results
    update_option( 'digipay_diagnostic_results', array(
        'results' => $results,
        'timestamp' => current_time( 'mysql' )
    ));
    
    return $results;
}

/**
 * Check if site is using HTTPS
 */
function digipay_check_ssl() {
    $is_ssl = is_ssl();
    $site_url = get_site_url();
    $uses_https = strpos( $site_url, 'https://' ) === 0;
    
    if ( $is_ssl && $uses_https ) {
        return array(
            'ok' => true,
            'message' => 'Site is using HTTPS'
        );
    }
    
    $message = 'Site is not using HTTPS. ';
    if ( ! $uses_https ) {
        $message .= 'Site URL is set to HTTP. ';
    }
    if ( ! $is_ssl ) {
        $message .= 'Current connection is not secure. ';
    }
    $message .= 'Postbacks require HTTPS to function properly.';
    
    return array(
        'ok' => false,
        'message' => $message
    );
}

/**
 * Check if cURL is installed and functioning
 */
function digipay_check_curl() {
    // Check if cURL extension is loaded
    if ( ! function_exists( 'curl_version' ) ) {
        return array(
            'ok' => false,
            'issue_code' => DIGIPAY_ISSUE_NO_CURL,
            'version' => null,
            'message' => 'cURL extension is not installed. Contact your hosting provider to enable cURL.'
        );
    }
    
    $curl_info = curl_version();
    $version = $curl_info['version'];
    
    // Check for very old cURL versions (pre 7.20 had SSL issues)
    $version_parts = explode( '.', $version );
    $major = intval( $version_parts[0] );
    $minor = isset( $version_parts[1] ) ? intval( $version_parts[1] ) : 0;
    
    if ( $major < 7 || ( $major == 7 && $minor < 20 ) ) {
        return array(
            'ok' => false,
            'issue_code' => DIGIPAY_ISSUE_CURL_OLD,
            'version' => $version,
            'message' => 'cURL version ' . $version . ' is outdated. Version 7.20+ required for proper SSL support.'
        );
    }
    
    // Check if cURL has SSL support
    if ( ! ( $curl_info['features'] & CURL_VERSION_SSL ) ) {
        return array(
            'ok' => false,
            'issue_code' => DIGIPAY_ISSUE_NO_OPENSSL,
            'version' => $version,
            'message' => 'cURL is installed but lacks SSL support. Contact your hosting provider.'
        );
    }
    
    return array(
        'ok' => true,
        'issue_code' => null,
        'version' => $version,
        'message' => 'cURL ' . $version . ' is installed with SSL support'
    );
}

/**
 * Check OpenSSL availability
 */
function digipay_check_openssl() {
    if ( ! extension_loaded( 'openssl' ) ) {
        return array(
            'ok' => false,
            'version' => null,
            'message' => 'OpenSSL extension is not loaded. Required for secure API communication.'
        );
    }
    
    $version = defined( 'OPENSSL_VERSION_TEXT' ) ? OPENSSL_VERSION_TEXT : 'Unknown';
    
    return array(
        'ok' => true,
        'version' => $version,
        'message' => 'OpenSSL is available: ' . $version
    );
}

/**
 * Check outbound connectivity and detect firewall issues
 */
function digipay_check_connectivity() {
    $api_url = 'https://hzdybwclwqkcobpwxzoo.supabase.co/functions/v1/site-limits';
    $gateway = new WC_Gateway_Paygo_npaygo();
    $site_id = $gateway->get_option( 'siteid' );
    
    // Test with a simple request
    $start_time = microtime( true );
    $response = wp_remote_get( 
        add_query_arg( array( 'site_id' => $site_id ? $site_id : 'test' ), $api_url ),
        array(
            'timeout' => 15,
            'sslverify' => true,
            'headers' => array( 'Accept' => 'application/json' )
        )
    );
    $response_time = round( ( microtime( true ) - $start_time ) * 1000 );
    
    if ( is_wp_error( $response ) ) {
        $error_message = $response->get_error_message();
        $error_code = $response->get_error_code();
        
        // Analyze the error to determine likely cause
        $firewall_suspected = false;
        $issue_code = DIGIPAY_ISSUE_API_ERROR;
        
        // Connection timeout usually means firewall
        if ( strpos( $error_message, 'timed out' ) !== false || 
             strpos( $error_message, 'Connection timed out' ) !== false ||
             $error_code === 'http_request_failed' ) {
            $firewall_suspected = true;
            $issue_code = DIGIPAY_ISSUE_FIREWALL;
        }
        
        // cURL error 7 = couldn't connect (often firewall)
        if ( strpos( $error_message, 'cURL error 7' ) !== false ||
             strpos( $error_message, 'Failed to connect' ) !== false ) {
            $firewall_suspected = true;
            $issue_code = DIGIPAY_ISSUE_FIREWALL;
        }
        
        // cURL error 28 = timeout
        if ( strpos( $error_message, 'cURL error 28' ) !== false ) {
            $firewall_suspected = true;
            $issue_code = DIGIPAY_ISSUE_API_TIMEOUT;
        }
        
        // SSL certificate issues
        if ( strpos( $error_message, 'SSL' ) !== false ||
             strpos( $error_message, 'certificate' ) !== false ) {
            $issue_code = DIGIPAY_ISSUE_NO_OPENSSL;
        }
        
        $message = 'Cannot reach API: ' . $error_message;
        if ( $firewall_suspected ) {
            $message .= ' This is likely caused by a server-side firewall blocking outbound connections to our domain.';
        }
        
        return array(
            'ok' => false,
            'firewall_suspected' => $firewall_suspected,
            'issue_code' => $issue_code,
            'response_time' => $response_time,
            'message' => $message,
            'raw_error' => $error_message
        );
    }
    
    $response_code = wp_remote_retrieve_response_code( $response );
    
    if ( $response_code !== 200 ) {
        return array(
            'ok' => false,
            'firewall_suspected' => false,
            'issue_code' => DIGIPAY_ISSUE_API_ERROR,
            'response_time' => $response_time,
            'message' => 'API returned HTTP ' . $response_code . '. The API might be temporarily unavailable.'
        );
    }
    
    return array(
        'ok' => true,
        'firewall_suspected' => false,
        'issue_code' => null,
        'response_time' => $response_time,
        'message' => 'Successfully connected to API (' . $response_time . 'ms)'
    );
}

// ============================================================
// POSTBACK TRACKING
// ============================================================

/**
 * Track postback receipt and status
 * Call this in your postback handler when a postback is received
 */
function digipay_track_postback( $success = true, $error_message = '' ) {
    $stats = get_option( 'digipay_postback_stats', array(
        'success_count' => 0,
        'error_count' => 0,
        'last_received' => null,
        'last_success' => null,
        'last_error' => null,
        'last_error_message' => ''
    ));
    
    $stats['last_received'] = current_time( 'mysql' );
    
    if ( $success ) {
        $stats['success_count']++;
        $stats['last_success'] = current_time( 'mysql' );
    } else {
        $stats['error_count']++;
        $stats['last_error'] = current_time( 'mysql' );
        $stats['last_error_message'] = $error_message;
    }
    
    update_option( 'digipay_postback_stats', $stats );
    
    // Report to central dashboard
    digipay_report_health();
}

/**
 * Get postback statistics
 */
function digipay_get_postback_stats() {
    return get_option( 'digipay_postback_stats', array(
        'success_count' => 0,
        'error_count' => 0,
        'last_received' => null,
        'last_success' => null,
        'last_error' => null,
        'last_error_message' => ''
    ));
}

// ============================================================
// API CONNECTION TESTING
// ============================================================

/**
 * Test the API connection and return detailed results
 */
function digipay_test_api_connection() {
    $gateway = new WC_Gateway_Paygo_npaygo();
    $site_id = $gateway->get_option( 'siteid' );
    
    $result = array(
        'success' => false,
        'status' => 'error',
        'message' => '',
        'response_time_ms' => 0,
        'response_data' => null
    );
    
    if ( empty( $site_id ) ) {
        $result['message'] = 'Site ID not configured';
        return $result;
    }
    
    $api_url = $gateway->limits_api_url;
    $start_time = microtime( true );
    
    $response = wp_remote_get( 
        add_query_arg( array( 'site_id' => $site_id ), $api_url ),
        array(
            'timeout' => 15,
            'sslverify' => true,
            'headers' => array( 'Accept' => 'application/json' )
        )
    );
    
    $end_time = microtime( true );
    $result['response_time_ms'] = round( ( $end_time - $start_time ) * 1000 );
    
    if ( is_wp_error( $response ) ) {
        $result['message'] = 'Connection failed: ' . $response->get_error_message();
        return $result;
    }
    
    $response_code = wp_remote_retrieve_response_code( $response );
    $response_body = wp_remote_retrieve_body( $response );
    
    if ( $response_code !== 200 ) {
        $result['message'] = 'API returned HTTP ' . $response_code;
        return $result;
    }
    
    $data = json_decode( $response_body, true );
    
    if ( json_last_error() !== JSON_ERROR_NONE ) {
        $result['message'] = 'Invalid JSON response';
        return $result;
    }
    
    if ( ! isset( $data['success'] ) || ! $data['success'] ) {
        $result['message'] = 'API error: ' . ( $data['error'] ?? 'Unknown error' );
        return $result;
    }
    
    $result['success'] = true;
    $result['status'] = 'ok';
    $result['message'] = 'Connection successful';
    $result['response_data'] = $data;
    
    // Store last successful test
    update_option( 'digipay_api_last_test', array(
        'time' => current_time( 'mysql' ),
        'success' => true,
        'response_time_ms' => $result['response_time_ms']
    ));
    
    return $result;
}

// ============================================================
// HEALTH REPORTING TO CENTRAL DASHBOARD
// ============================================================

/**
 * Report health status to central dashboard
 */
function digipay_report_health() {
    $gateway = new WC_Gateway_Paygo_npaygo();
    $site_id = $gateway->get_option( 'siteid' );
    
    if ( empty( $site_id ) ) {
        return false;
    }
    
    // Get diagnostic results
    $diagnostics = get_option( 'digipay_diagnostic_results', array() );
    $diag_results = isset( $diagnostics['results'] ) ? $diagnostics['results'] : array();
    
    // Get API test results
    $api_test = get_option( 'digipay_api_last_test', array() );
    
    // Get postback stats
    $postback_stats = digipay_get_postback_stats();
    
    // Determine statuses
    $api_status = 'unknown';
    if ( ! empty( $api_test['success'] ) ) {
        $api_status = 'ok';
    } elseif ( isset( $api_test['success'] ) && ! $api_test['success'] ) {
        $api_status = 'error';
    }
    
    $postback_status = 'unknown';
    if ( $postback_stats['success_count'] > 0 && $postback_stats['error_count'] == 0 ) {
        $postback_status = 'ok';
    } elseif ( $postback_stats['error_count'] > 0 && $postback_stats['success_count'] == 0 ) {
        $postback_status = 'error';
    } elseif ( $postback_stats['success_count'] > 0 && $postback_stats['error_count'] > 0 ) {
        $total = $postback_stats['success_count'] + $postback_stats['error_count'];
        $success_rate = ( $postback_stats['success_count'] / $total ) * 100;
        $postback_status = $success_rate >= 90 ? 'ok' : 'error';
    }
    
    // Build health report
    $health_data = array(
        'site_id' => $site_id,
        'site_name' => get_bloginfo( 'name' ),
        'site_url' => get_site_url(),
        
        // API status
        'api_status' => $api_status,
        'api_last_check' => $api_test['time'] ?? null,
        'api_last_success' => $api_status === 'ok' ? ( $api_test['time'] ?? null ) : null,
        'api_response_time_ms' => $api_test['response_time_ms'] ?? null,
        
        // Postback status
        'postback_status' => $postback_status,
        'postback_last_received' => $postback_stats['last_received'],
        'postback_last_success' => $postback_stats['last_success'],
        'postback_success_count' => $postback_stats['success_count'],
        'postback_error_count' => $postback_stats['error_count'],
        'postback_last_error' => $postback_stats['last_error_message'],
        
        // Environment diagnostics
        'has_ssl' => $diag_results['has_ssl'] ?? null,
        'has_curl' => $diag_results['has_curl'] ?? null,
        'curl_version' => $diag_results['curl_version'] ?? null,
        'openssl_version' => $diag_results['openssl_version'] ?? null,
        'can_reach_api' => $diag_results['can_reach_api'] ?? null,
        'firewall_issue' => $diag_results['firewall_issue'] ?? null,
        'server_software' => $diag_results['server_software'] ?? null,
        
        // Diagnostic issues
        'diagnostic_issues' => $diag_results['issues'] ?? array(),
        'diagnostic_details' => implode( ' | ', $diag_results['details'] ?? array() ),
        'last_diagnostic_run' => $diagnostics['timestamp'] ?? null,
        
        // Version info
        'plugin_version' => '12.4.0',
        'wordpress_version' => get_bloginfo( 'version' ),
        'woocommerce_version' => defined( 'WC_VERSION' ) ? WC_VERSION : 'unknown',
        'php_version' => phpversion()
    );
    
    // Send to central dashboard
    $response = wp_remote_post( 
        'https://hzdybwclwqkcobpwxzoo.supabase.co/functions/v1/site-health-report',
        array(
            'timeout' => 10,
            'headers' => array( 'Content-Type' => 'application/json' ),
            'body' => json_encode( $health_data )
        )
    );
    
    return ! is_wp_error( $response );
}

// ============================================================
// ADMIN DIAGNOSTICS PAGE
// ============================================================

/**
 * Add diagnostics section to WooCommerce payment gateway settings
 */
add_action( 'woocommerce_settings_checkout', 'digipay_display_diagnostics' );
function digipay_display_diagnostics() {
    if ( ! isset( $_GET['section'] ) || $_GET['section'] !== 'paygobillingcc' ) {
        return;
    }
    
    // Handle test actions
    if ( isset( $_GET['digipay_action'] ) ) {
        $action = sanitize_text_field( $_GET['digipay_action'] );
        
        if ( $action === 'run_diagnostics' ) {
            $results = digipay_run_diagnostics();
            digipay_test_api_connection();
            digipay_report_health();
            
            if ( empty( $results['issues'] ) ) {
                echo '<div class="notice notice-success"><p><strong>✓ All Diagnostics Passed!</strong> Your site is configured correctly.</p></div>';
            } else {
                echo '<div class="notice notice-error"><p><strong>Issues Found:</strong> See details below.</p></div>';
            }
        }
        
        if ( $action === 'test_api' ) {
            $result = digipay_test_api_connection();
            digipay_report_health();
            
            if ( $result['success'] ) {
                echo '<div class="notice notice-success"><p><strong>✓ API Connection Successful!</strong> Response time: ' . $result['response_time_ms'] . 'ms</p></div>';
            } else {
                echo '<div class="notice notice-error"><p><strong>✗ API Connection Failed:</strong> ' . esc_html( $result['message'] ) . '</p></div>';
            }
        }
        
        if ( $action === 'reset_postback_stats' ) {
            delete_option( 'digipay_postback_stats' );
            digipay_report_health();
            echo '<div class="notice notice-success"><p>Postback statistics reset.</p></div>';
        }
        
        if ( $action === 'report_health' ) {
            $success = digipay_report_health();
            if ( $success ) {
                echo '<div class="notice notice-success"><p>Health report sent to dashboard.</p></div>';
            } else {
                echo '<div class="notice notice-error"><p>Failed to send health report.</p></div>';
            }
        }
    }
    
    // Get current data
    $diagnostics = get_option( 'digipay_diagnostic_results', array() );
    $diag_results = isset( $diagnostics['results'] ) ? $diagnostics['results'] : array();
    $diag_time = isset( $diagnostics['timestamp'] ) ? $diagnostics['timestamp'] : null;
    
    $api_test = get_option( 'digipay_api_last_test', array() );
    $postback_stats = digipay_get_postback_stats();
    
    // Calculate postback success rate
    $postback_total = $postback_stats['success_count'] + $postback_stats['error_count'];
    $postback_rate = $postback_total > 0 
        ? round( ( $postback_stats['success_count'] / $postback_total ) * 100, 1 ) 
        : null;
    
    $has_issues = ! empty( $diag_results['issues'] );
    
    ?>
    <div style="background: #fff; border: 1px solid #ccd0d4; border-left: 4px solid <?php echo $has_issues ? '#dc3232' : '#2271b1'; ?>; padding: 15px 20px; margin: 20px 0; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
        <h3 style="margin-top: 0; display: flex; align-items: center; gap: 10px;">
            <span>🔧 Diagnostics & Troubleshooting</span>
            <?php if ( $has_issues ) : ?>
                <span style="background: #dc3232; color: white; font-size: 11px; padding: 2px 8px; border-radius: 3px;"><?php echo count( $diag_results['issues'] ); ?> Issues</span>
            <?php endif; ?>
        </h3>
        
        <!-- Quick Actions -->
        <div style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
            <a href="<?php echo add_query_arg( 'digipay_action', 'run_diagnostics' ); ?>" class="button button-primary">Run Full Diagnostics</a>
            <a href="<?php echo add_query_arg( 'digipay_action', 'test_api' ); ?>" class="button">Test API Only</a>
            <a href="<?php echo add_query_arg( 'digipay_action', 'report_health' ); ?>" class="button">Send Health Report</a>
        </div>
        
        <?php if ( $diag_time ) : ?>
            <p style="color: #666; font-size: 12px; margin-bottom: 15px;">Last diagnostics run: <?php echo $diag_time; ?></p>
        <?php endif; ?>
        
        <!-- Issues Section -->
        <?php if ( $has_issues ) : ?>
            <div style="background: #fef2f2; border: 1px solid #fecaca; border-radius: 4px; padding: 15px; margin-bottom: 20px;">
                <h4 style="margin: 0 0 10px 0; color: #dc3232;">⚠ Issues Detected</h4>
                <?php foreach ( $diag_results['issues'] as $index => $issue_code ) : ?>
                    <div style="background: white; border-left: 3px solid #dc3232; padding: 10px 15px; margin-bottom: 10px;">
                        <strong style="color: #dc3232;"><?php echo digipay_get_issue_title( $issue_code ); ?></strong>
                        <p style="margin: 5px 0 0 0; color: #666;"><?php echo isset( $diag_results['details'][$index] ) ? esc_html( $diag_results['details'][$index] ) : ''; ?></p>
                        <p style="margin: 5px 0 0 0; color: #2271b1; font-size: 12px;"><strong>Fix:</strong> <?php echo digipay_get_issue_fix( $issue_code ); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <table class="form-table" style="margin: 0;">
            <!-- SSL Status -->
            <tr>
                <th scope="row" style="padding: 12px 0; width: 180px;">HTTPS / SSL</th>
                <td style="padding: 12px 0;">
                    <?php if ( isset( $diag_results['has_ssl'] ) ) : ?>
                        <?php if ( $diag_results['has_ssl'] ) : ?>
                            <span style="color: #00a32a; font-weight: 600;">✓ Enabled</span>
                        <?php else : ?>
                            <span style="color: #dc3232; font-weight: 600;">✗ Not Enabled</span>
                            <br><small style="color: #dc3232;">Postbacks require HTTPS</small>
                        <?php endif; ?>
                    <?php else : ?>
                        <span style="color: #dba617;">? Not checked</span>
                    <?php endif; ?>
                </td>
            </tr>
            
            <!-- cURL Status -->
            <tr>
                <th scope="row" style="padding: 12px 0;">cURL Extension</th>
                <td style="padding: 12px 0;">
                    <?php if ( isset( $diag_results['has_curl'] ) ) : ?>
                        <?php if ( $diag_results['has_curl'] ) : ?>
                            <span style="color: #00a32a; font-weight: 600;">✓ Installed</span>
                            <?php if ( $diag_results['curl_version'] ) : ?>
                                <span style="color: #666; margin-left: 5px;">(v<?php echo esc_html( $diag_results['curl_version'] ); ?>)</span>
                            <?php endif; ?>
                        <?php else : ?>
                            <span style="color: #dc3232; font-weight: 600;">✗ Not Available</span>
                            <br><small style="color: #dc3232;">Required for API communication</small>
                        <?php endif; ?>
                    <?php else : ?>
                        <span style="color: #dba617;">? Not checked</span>
                    <?php endif; ?>
                </td>
            </tr>
            
            <!-- OpenSSL Status -->
            <tr>
                <th scope="row" style="padding: 12px 0;">OpenSSL</th>
                <td style="padding: 12px 0;">
                    <?php if ( $diag_results['openssl_version'] ) : ?>
                        <span style="color: #00a32a; font-weight: 600;">✓ Available</span>
                        <span style="color: #666; margin-left: 5px;">(<?php echo esc_html( $diag_results['openssl_version'] ); ?>)</span>
                    <?php elseif ( isset( $diag_results['openssl_version'] ) ) : ?>
                        <span style="color: #dc3232; font-weight: 600;">✗ Not Available</span>
                    <?php else : ?>
                        <span style="color: #dba617;">? Not checked</span>
                    <?php endif; ?>
                </td>
            </tr>
            
            <!-- Connectivity / Firewall -->
            <tr>
                <th scope="row" style="padding: 12px 0;">Outbound Connectivity</th>
                <td style="padding: 12px 0;">
                    <?php if ( isset( $diag_results['can_reach_api'] ) ) : ?>
                        <?php if ( $diag_results['can_reach_api'] ) : ?>
                            <span style="color: #00a32a; font-weight: 600;">✓ Connected</span>
                        <?php else : ?>
                            <span style="color: #dc3232; font-weight: 600;">✗ Blocked</span>
                            <?php if ( $diag_results['firewall_issue'] ) : ?>
                                <br><small style="color: #dc3232;"><strong>Firewall Issue Detected:</strong> Your server's firewall is blocking outbound connections.</small>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php else : ?>
                        <span style="color: #dba617;">? Not checked</span>
                    <?php endif; ?>
                </td>
            </tr>
            
            <tr><td colspan="2"><hr style="border: none; border-top: 1px solid #eee; margin: 10px 0;"></td></tr>
            
            <!-- API Connection Status -->
            <tr>
                <th scope="row" style="padding: 12px 0;">API Connection</th>
                <td style="padding: 12px 0;">
                    <?php if ( ! empty( $api_test['success'] ) ) : ?>
                        <span style="color: #00a32a; font-weight: 600;">✓ Working</span>
                        <span style="color: #666; margin-left: 10px;">(<?php echo $api_test['response_time_ms']; ?>ms)</span>
                    <?php elseif ( isset( $api_test['success'] ) && ! $api_test['success'] ) : ?>
                        <span style="color: #dc3232; font-weight: 600;">✗ Error</span>
                    <?php else : ?>
                        <span style="color: #dba617; font-weight: 600;">? Not tested</span>
                    <?php endif; ?>
                    
                    <?php if ( ! empty( $api_test['time'] ) ) : ?>
                        <br><small style="color: #666;">Last tested: <?php echo $api_test['time']; ?></small>
                    <?php endif; ?>
                </td>
            </tr>
            
            <!-- Postback Status -->
            <tr>
                <th scope="row" style="padding: 12px 0;">Postback Status</th>
                <td style="padding: 12px 0;">
                    <?php if ( $postback_rate !== null ) : ?>
                        <?php if ( $postback_rate >= 95 ) : ?>
                            <span style="color: #00a32a; font-weight: 600;">✓ Healthy</span>
                        <?php elseif ( $postback_rate >= 80 ) : ?>
                            <span style="color: #dba617; font-weight: 600;">⚠ Degraded</span>
                        <?php else : ?>
                            <span style="color: #dc3232; font-weight: 600;">✗ Failing</span>
                        <?php endif; ?>
                        <span style="color: #666; margin-left: 10px;">(<?php echo $postback_rate; ?>% success rate)</span>
                    <?php else : ?>
                        <span style="color: #dba617; font-weight: 600;">? No data yet</span>
                        <br><small style="color: #666;">Stats will appear after first transaction</small>
                    <?php endif; ?>
                    
                    <br><small style="color: #666;">
                        <span style="color: #00a32a;">✓ <?php echo $postback_stats['success_count']; ?></span> successful, 
                        <span style="color: #dc3232;">✗ <?php echo $postback_stats['error_count']; ?></span> failed
                        <a href="<?php echo add_query_arg( 'digipay_action', 'reset_postback_stats' ); ?>" style="margin-left: 10px;" onclick="return confirm('Reset postback statistics?');">Reset</a>
                    </small>
                    
                    <?php if ( $postback_stats['last_received'] ) : ?>
                        <br><small style="color: #666;">Last received: <?php echo $postback_stats['last_received']; ?></small>
                    <?php endif; ?>
                    
                    <?php if ( $postback_stats['last_error_message'] ) : ?>
                        <br><small style="color: #dc3232;">Last error: <?php echo esc_html( $postback_stats['last_error_message'] ); ?></small>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        
        <!-- Server Info -->
        <details style="margin-top: 15px;">
            <summary style="cursor: pointer; color: #2271b1;">Server Information</summary>
            <div style="background: #f8f8f8; padding: 10px 15px; margin-top: 10px; border-radius: 4px; font-family: monospace; font-size: 12px;">
                <p style="margin: 5px 0;">PHP Version: <?php echo phpversion(); ?></p>
                <p style="margin: 5px 0;">WordPress: <?php echo get_bloginfo( 'version' ); ?></p>
                <p style="margin: 5px 0;">WooCommerce: <?php echo defined( 'WC_VERSION' ) ? WC_VERSION : 'N/A'; ?></p>
                <p style="margin: 5px 0;">Server: <?php echo isset( $_SERVER['SERVER_SOFTWARE'] ) ? esc_html( $_SERVER['SERVER_SOFTWARE'] ) : 'Unknown'; ?></p>
                <p style="margin: 5px 0;">Site URL: <?php echo get_site_url(); ?></p>
            </div>
        </details>
    </div>
    <?php
}

/**
 * Get human-readable issue title
 */
function digipay_get_issue_title( $issue_code ) {
    $titles = array(
        'NO_SSL' => '🔓 HTTPS Not Enabled',
        'NO_CURL' => '⚙️ cURL Not Installed',
        'CURL_OLD' => '⚙️ cURL Version Outdated',
        'NO_OPENSSL' => '🔐 OpenSSL Not Available',
        'FIREWALL' => '🛡️ Firewall Blocking Connections',
        'API_TIMEOUT' => '⏱️ API Connection Timeout',
        'API_ERROR' => '❌ API Connection Error',
        'POSTBACK_FAIL' => '📬 Postbacks Failing'
    );
    return isset( $titles[$issue_code] ) ? $titles[$issue_code] : $issue_code;
}

/**
 * Get fix instructions for issue
 */
function digipay_get_issue_fix( $issue_code ) {
    $fixes = array(
        'NO_SSL' => 'Install an SSL certificate and update your Site URL to use https://. Most hosts offer free SSL via Let\'s Encrypt.',
        'NO_CURL' => 'Contact your hosting provider and ask them to enable the PHP cURL extension.',
        'CURL_OLD' => 'Contact your hosting provider to update cURL to version 7.20 or higher.',
        'NO_OPENSSL' => 'Contact your hosting provider and ask them to enable the PHP OpenSSL extension.',
        'FIREWALL' => 'Contact your hosting provider and ask them to whitelist outbound connections to: hzdybwclwqkcobpwxzoo.supabase.co. If using a security plugin (Wordfence, Sucuri), add this domain to the allowlist.',
        'API_TIMEOUT' => 'This may be a temporary network issue. If it persists, contact your hosting provider about slow outbound connections.',
        'API_ERROR' => 'Check if the API endpoint is accessible. This may be a temporary service issue.',
        'POSTBACK_FAIL' => 'Check that your site has HTTPS enabled and is publicly accessible. Verify no security plugins are blocking incoming requests.'
    );
    return isset( $fixes[$issue_code] ) ? $fixes[$issue_code] : 'Contact your hosting provider for assistance.';
}

// ============================================================
// AUTOMATIC HEALTH REPORTING
// ============================================================

/**
 * Schedule daily health report
 */
register_activation_hook( __FILE__, 'digipay_schedule_health_report' );
function digipay_schedule_health_report() {
    if ( ! wp_next_scheduled( 'digipay_daily_health_report' ) ) {
        wp_schedule_event( time(), 'daily', 'digipay_daily_health_report' );
    }
}

add_action( 'digipay_daily_health_report', 'digipay_daily_health_check' );
function digipay_daily_health_check() {
    // Run full diagnostics
    digipay_run_diagnostics();
    
    // Test API
    digipay_test_api_connection();
    
    // Report health
    digipay_report_health();
}

/**
 * Clean up on deactivation
 */
register_deactivation_hook( __FILE__, 'digipay_clear_scheduled_events' );
function digipay_clear_scheduled_events() {
    wp_clear_scheduled_hook( 'digipay_daily_health_report' );
}
