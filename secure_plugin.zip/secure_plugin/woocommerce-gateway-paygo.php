<?php
/*
Plugin Name: Digipay
Description: Payment gateway for woocommerce
Version: 12.4.0
Author: digipay
Author URI: digipay
*/
 
defined( 'ABSPATH' ) or exit;

// Load diagnostics & health reporting module
require_once( plugin_dir_path( __FILE__ ) . 'digipay-diagnostics.php' );

// Make sure WooCommerce is active
if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	return;
}
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

 $encryption_key = "fluidcastplgpaygowoo22";

 function encrypt($string,  $key)
    {  $encryptMethod = 'AES-256-CBC';
    	$number = (int) filter_var($encryptMethod, FILTER_SANITIZE_NUMBER_INT);

       $encryptMethodLength =intval(abs($number));

        $ivLength = openssl_cipher_iv_length($encryptMethod);
        $iv = openssl_random_pseudo_bytes($ivLength);
 
        $salt = openssl_random_pseudo_bytes(256);
        $iterations = 999;
        $hashKey = hash_pbkdf2('sha512', $key, $salt, $iterations, ($encryptMethodLength / 4));

        $encryptedString = openssl_encrypt($string, $encryptMethod, hex2bin($hashKey), OPENSSL_RAW_DATA, $iv);

        $encryptedString = base64_encode($encryptedString);
        unset($hashKey);

        $output = ['ciphertext' => $encryptedString, 'iv' => bin2hex($iv), 'salt' => bin2hex($salt), 'iterations' => $iterations];
        unset($encryptedString, $iterations, $iv, $ivLength, $salt);

        return base64_encode(json_encode($output));
    }// encrypt

/**
 * Add the gateway to WC Available Gateways
 * 
 * @since 1.0.0
 * @param array $gateways all available WC gateways
 * @return array $gateways all WC gateways + gateway
 */
function wc_paygo_add_to_gateways_npaygo( $gateways ) {
	$gateways[] = 'WC_Gateway_paygo_npaygo';
	return $gateways;
}
add_filter( 'woocommerce_payment_gateways', 'wc_paygo_add_to_gateways_npaygo' );


/**
 * Adds plugin page links
 * 
 * @since 1.0.0
 * @param array $links all plugin links
 * @return array $links all plugin links + our custom links (i.e., "Settings")
 */
function wc_paygo_gateway_plugin_links_npaygo( $links ) {

	$plugin_links = array(
		'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=paygobillingcc' ) . '">' . __( 'Configure', 'wc-gateway-paygo' ) . '</a>'
	);

	return array_merge( $plugin_links, $links );
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'wc_paygo_gateway_plugin_links_npaygo' );


/**
 * PayGo Payment Gateway
 * @class 		WC_Gateway_Secure
 * @extends		WC_Payment_Gateway
 * @version		1.0.0
 * @package		WooCommerce/Classes/Payment
 * @author 		Hridaya Ghimire
 */


//for by CC  -- USED
add_action( 'plugins_loaded', 'wc_paygo_gateway_init_npaygo', 0 );

function wc_paygo_gateway_init_npaygo() {
#[AllowDynamicProperties]

	class WC_Gateway_Paygo_npaygo extends WC_Payment_Gateway {

		 public $title ;
		 public $description ;
		 public $instructions ;
		 public $siteid ;
		 public $encrypt_description ;
		 public $tocomplete ;
		 public $paygomainurl ;
		 public $limits_api_url ;
		 public $daily_limit ;
		 public $max_ticket_size ;


		/**
		 * Constructor for the gateway.
		 */
		public function __construct() {
	  
			$this->id                 = 'paygobillingcc';
			$this->icon               = apply_filters('woocommerce_paygo_icon', '');
			$this->has_fields         = false;
			$this->method_title       = __( 'Digipay Gateway', 'wc-gateway-paygo' );
			$this->method_description = __( 'Allows payments.', 'wc-gateway-paygo' );
		  
			// Load the settings.
			$this->init_form_fields();
			$this->init_settings();
		  
			// Define user set variables
			$this->title        = @$this->get_option( 'title' );
			$this->description  = @$this->get_option( 'description' );
			//$this->instructions = @$this->get_option( 'instructions');
			$this->siteid = @$this->get_option( 'siteid');
			$this->encrypt_description = @$this->get_option( 'encrypt_description');


			
			//$this->paygopayment_method = $this->get_option( 'paygopayment_method', $this->paygopayment_method );
			$this->tocomplete  = @$this->get_option( 'tocomplete' );
			// API base URL for fetching transaction limits from your dashboard
			$this->limits_api_url = 'https://hzdybwclwqkcobpwxzoo.supabase.co/functions/v1/site-limits';
			// Keep original URL for payment processing
			$this->paygomainurl  = 'https://secure.digipay.co/';
			
			// Fetch limits from Digipay central dashboard
			$remote_limits = $this->get_remote_limits();
			$this->daily_limit = $remote_limits['daily_limit'];
			$this->max_ticket_size = $remote_limits['max_ticket_size']; 

		//  exit;
			// Actions
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
			
		// add_filter( 'woocommerce_order_button_text',  array( $this,'woo_custom_order_button_text'), 10, 3 ); 


			// Customer Emails
			//add_action( 'woocommerce_email_before_order_table', array( $this, 'email_instructions' ), 10, 3 );


			
		}
	


		/**
		 * Initialize Gateway Settings Form Fields
		 */
		public function init_form_fields() {


		

			$this->form_fields = apply_filters( 'wc_paygo_form_fields', array(
		  
				'enabled' => array(
					'title'   => __( 'Enable/Disable', 'wc-gateway-paygo' ),
					'type'    => 'checkbox',
					'label'   => __( 'Enable Credit Card payments', 'wc-gateway-paygo' ),
					'default' => 'yes'
				),
				'encrypt_description' => array(
					'title'   => __( 'Enable/Disable', 'wc-gateway-paygo' ),
					'type'    => 'checkbox',
					'label'   => __( 'Encrypt Description', 'wc-gateway-paygo' ),
					'default' => 'yes'
				),
				'title' => array(
					'title'       => __( 'Title', 'wc-gateway-paygo' ),
					'type'        => 'text',
					'description' => __( 'This controls the title for the payment method the customer sees during checkout.', 'wc-gateway-paygo' ),
					'default'     => __( 'Credit Card', 'wc-gateway-paygo' ),
					'desc_tip'    => true,
				),

				'siteid' => array(
					'title'       => __( 'Site ID', 'wc-gateway-paygo' ),
					'type'        => 'text',
					'description' => __( 'Your Site id.', 'wc-gateway-paygo' ),
					'default'     => '',
					'desc_tip'    => true,
				),
				
				'description' => array(
					'title'       => __( 'Description', 'wc-gateway-paygo' ),
					'type'        => 'textarea',
					'description' => __( 'Payment method description that the customer will see on your checkout.', 'wc-gateway-paygo' ),
					'default'     => '',
					'desc_tip'    => true,
				),
				'tocomplete' => array(
					'title'       => __( 'Redirect URL after complete', 'wc-gateway-paygo' ),
					'type'        => 'text',
					'description' => __( 'Redirect to this url when complete payment.', 'wc-gateway-paygo' ),
					//'default'     => __( 'Make a payment through your bank in Canada using Interac', 'wc-gateway-paygo' ),
					'desc_tip'    => true,
				),


				
				/* 'instructions' => array(
					'title'       => __( 'Instructions', 'wc-gateway-paygo' ),
					'type'        => 'textarea',
					'description' => __( 'Instructions that will be added to the thank you page and emails.', 'wc-gateway-paygo' ),
					'default'     => '',
					'desc_tip'    => true,
				), */
			) );
		}


		
		/**
		 * Output for the order received page.
		 */
		public function thankyou_page() {
			if ( $this->description ) {
				//echo wpautop( wptexturize( $this->description ) );
			}
		}

		/**
		 * Check if the gateway is available for use.
		 *
		 * @return bool
		 */
		public function is_available() {
			// First check parent availability (enabled setting, etc.)
			if ( ! parent::is_available() ) {
				return false;
			}

			// Check max ticket size limit
			if ( $this->max_ticket_size && floatval( $this->max_ticket_size ) > 0 ) {
				$cart_total = $this->get_current_order_total();
				if ( $cart_total > floatval( $this->max_ticket_size ) ) {
					return false;
				}
			}

			// Check daily transaction limit
			if ( $this->daily_limit && floatval( $this->daily_limit ) > 0 ) {
				$daily_total = $this->get_daily_transaction_total();
				if ( $daily_total >= floatval( $this->daily_limit ) ) {
					return false;
				}
			}

			return true;
		}

		/**
		 * Get current cart or order total
		 *
		 * @return float
		 */
		private function get_current_order_total() {
			// If we're on checkout and have a cart
			if ( WC()->cart ) {
				return floatval( WC()->cart->get_total( 'edit' ) );
			}
			return 0;
		}

		/**
		 * Get the total transaction amount for today
		 *
		 * @return float
		 */
		public function get_daily_transaction_total() {
			$today = date( 'Y-m-d' );
			$transient_key = 'digipay_daily_total_' . $today;
			
			$daily_total = get_transient( $transient_key );
			
			if ( $daily_total === false ) {
				// Calculate from database if transient expired or doesn't exist
				$daily_total = $this->calculate_daily_total_from_orders();
				// Store for 24 hours (will auto-reset next day due to date in key)
				set_transient( $transient_key, $daily_total, DAY_IN_SECONDS );
			}
			
			return floatval( $daily_total );
		}

		/**
		 * Calculate daily total from completed orders
		 *
		 * @return float
		 */
		private function calculate_daily_total_from_orders() {
			$today_start = date( 'Y-m-d 00:00:00' );
			$today_end = date( 'Y-m-d 23:59:59' );

			$args = array(
				'payment_method' => 'paygobillingcc',
				'status'         => array( 'processing', 'completed' ),
				'date_created'   => $today_start . '...' . $today_end,
				'return'         => 'ids',
				'limit'          => -1,
			);

			$orders = wc_get_orders( $args );
			$total = 0;

			foreach ( $orders as $order_id ) {
				$order = wc_get_order( $order_id );
				if ( $order ) {
					$total += floatval( $order->get_total() );
				}
			}

			return $total;
		}

		/**
		 * Update the daily transaction total (call after successful payment)
		 *
		 * @param float $amount Amount to add to daily total
		 */
		public function update_daily_transaction_total( $amount ) {
			$today = date( 'Y-m-d' );
			$transient_key = 'digipay_daily_total_' . $today;
			
			$current_total = $this->get_daily_transaction_total();
			$new_total = $current_total + floatval( $amount );
			
			set_transient( $transient_key, $new_total, DAY_IN_SECONDS );
		}

		/**
		 * Get remaining daily limit
		 *
		 * @return float|null Returns remaining amount or null if no limit set
		 */
		public function get_remaining_daily_limit() {
			if ( ! $this->daily_limit || floatval( $this->daily_limit ) <= 0 ) {
				return null;
			}
			
			$daily_total = $this->get_daily_transaction_total();
			$remaining = floatval( $this->daily_limit ) - $daily_total;
			
			return max( 0, $remaining );
		}

		/**
		 * Fetch transaction limits from central dashboard (Supabase Edge Function)
		 * Caches the result for 5 minutes to avoid excessive API calls
		 *
		 * @return array Array with 'daily_limit' and 'max_ticket_size'
		 */
		public function get_remote_limits() {
			$site_id = $this->get_option( 'siteid' );
			
			// Default limits (no restrictions)
			$default_limits = array(
				'daily_limit'     => 0,
				'max_ticket_size' => 0,
				'last_updated'    => null,
				'status'          => 'unknown',
			);

			if ( empty( $site_id ) ) {
				return $default_limits;
			}

			$transient_key = 'digipay_remote_limits_' . md5( $site_id );
			$cached_limits = get_transient( $transient_key );

			// Return cached limits if available
			if ( $cached_limits !== false ) {
				return $cached_limits;
			}

			// Fetch from Supabase Edge Function
			$api_url = $this->limits_api_url;
			
			$response = wp_remote_get( 
				add_query_arg( array( 'site_id' => $site_id ), $api_url ),
				array(
					'timeout'   => 15,
					'sslverify' => true,
					'headers'   => array(
						'Accept' => 'application/json',
					),
				)
			);

			// If API request failed, try to use last known limits from options
			if ( is_wp_error( $response ) ) {
				$fallback_limits = get_option( 'digipay_last_known_limits_' . md5( $site_id ), $default_limits );
				// Cache the fallback for 1 minute before retrying
				set_transient( $transient_key, $fallback_limits, MINUTE_IN_SECONDS );
				return $fallback_limits;
			}

			$response_code = wp_remote_retrieve_response_code( $response );
			$response_body = wp_remote_retrieve_body( $response );

			if ( $response_code !== 200 ) {
				$fallback_limits = get_option( 'digipay_last_known_limits_' . md5( $site_id ), $default_limits );
				set_transient( $transient_key, $fallback_limits, MINUTE_IN_SECONDS );
				return $fallback_limits;
			}

			$data = json_decode( $response_body, true );

			if ( json_last_error() !== JSON_ERROR_NONE || ! isset( $data['success'] ) || ! $data['success'] ) {
				$fallback_limits = get_option( 'digipay_last_known_limits_' . md5( $site_id ), $default_limits );
				set_transient( $transient_key, $fallback_limits, MINUTE_IN_SECONDS );
				return $fallback_limits;
			}

			$limits = array(
				'daily_limit'     => floatval( $data['daily_limit'] ?? 0 ),
				'max_ticket_size' => floatval( $data['max_ticket_size'] ?? 0 ),
				'last_updated'    => current_time( 'mysql' ),
				'status'          => $data['status'] ?? 'active',
			);

			// Cache for 5 minutes
			set_transient( $transient_key, $limits, 5 * MINUTE_IN_SECONDS );
			
			// Also store as last known limits (persists beyond transient expiry)
			update_option( 'digipay_last_known_limits_' . md5( $site_id ), $limits, false );

			return $limits;
		}

		/**
		 * Force refresh of remote limits (clears cache)
		 */
		public function refresh_remote_limits() {
			$site_id = $this->get_option( 'siteid' );
			if ( ! empty( $site_id ) ) {
				delete_transient( 'digipay_remote_limits_' . md5( $site_id ) );
			}
			return $this->get_remote_limits();
		}
	
	
		/**
		 * Add content to the WC emails.
		 *
		 * @access public
		 * @param WC_Order $order
		 * @param bool $sent_to_admin
		 * @param bool $plain_text
		 */
		public function email_instructions( $order, $sent_to_admin, $plain_text = false ) {
		
			if ( $this->description && ! $sent_to_admin && $this->id === $order->payment_method && $order->has_status( 'pending' ) ) {
				echo wpautop( wptexturize( $this->description ) ) . PHP_EOL;
			}
		}


	
		/**
		 * Process the payment and return the result
		 *
		 * @param int $order_id
		 * @return array
		 */
		public function process_payment( $order_id ) {

			global $encryption_key;

			/*// Get the current date and time
			$currentDate = new DateTime();
			// Calculate the start date by subtracting 30 days
			$start_date = $currentDate->sub(new DateInterval('P30D'))->format('Y-m-d');

			// Reset the current date back to the original for end date calculation
			$currentDate = new DateTime();

			// Calculate the end date as today
			$end_date = $currentDate->format('Y-m-d');'date_query' => array(
			        'after'     => $start_date,
			        'before'    => $end_date,
			        'inclusive' => true,
			    ),

			*/


			$current_user = wp_get_current_user();
			$user_id =  $current_user->ID;
			//echo $numorders = wc_get_customer_order_count( $user_id );
			$order_status = array('processing','completed'); // Replace with the desired order status
			$args = array(
			    'customer_id' => $user_id,
			    'post_status' => $order_status,
			    'return' => 'ids','limit' => -1
			);
			$customer_orders = wc_get_orders($args);
			$count_orders=  count( $customer_orders );

			$order = wc_get_order( $order_id );
			$order_data = $order->get_data(); // The Order data

			if ($order && !is_wp_error($order)) {
				    $order_key = $order->get_order_key();
				}


			$product_name=array();
			$items = $order->get_items();
				foreach ( $items as $item ) {
				    $product_name[] = $item['name'];
				    
				}

				if($this->encrypt_description=="yes"){
					$paygoitems = $order_id;//implode("&",$product_name);

				}else{
					$paygoitems =implode("&",$product_name);

				}
				

				$order->get_shipping_methods(); 
				/* $shippedOptions=trim($order->get_shipping_method());
  				if(trim($shippedOptions)=="In Person")
  				{
  					$additionalparam="&shipping=0";
  				} else { $additionalparam=""; }

  				*/

				//https://secure.digipay.co/order/creditcard/cc_form.php?site_id=5809&charge_amount=35.00&type=purchase&order_description=Big%20leafs%20and%20ayame&woocomerce=1&session=91&address=&city=&state=&zip=&country=

				//$order_billing_name = $order_data['billing']['first_name']." " .$order_data['billing']['last_name'];
				$order_first_name = $order_data['billing']['first_name'];

				$order_last_name= $order_data['billing']['last_name'];

				$order_billing_email =$order_data['billing']['email'];
				$name_email_param="";
				
				if($order_first_name!=""){ $name_email_param="&first_name=".$order_first_name;}
				if($order_last_name!=""){ $name_email_param.="&last_name=".$order_last_name;}
				if($order_billing_email!=""){ $name_email_param.="&email=".$order_billing_email;}

				$order_billing_address_1 = $order_data['billing']['address_1'];
				$order_billing_address_2 = $order_data['billing']['address_2'];
				$order_billing_city = $order_data['billing']['city'];
				$order_billing_state = $order_data['billing']['state'];
				$order_billing_postcode = $order_data['billing']['postcode'];
				$order_billing_country = $order_data['billing']['country'];
				

				$address =$order_billing_address_1;
				if($order_billing_address_2!=""){
					$address.=" ".$order_billing_address_2;
				}

				if($this->paygoshipped=="yes"){
					$shipped="&shipped=0";
				}else{ $shipped="";}


				if($this->paygomainurl!=""){ 
					$mainURLpaygo = $this->paygomainurl;
					
				}else{

					$mainURLpaygo = "https://secure.digipay.co/";
				}


				if($this->paygo_enable_card_gateway=="yes"){
					//$url_main=$mainURLpaygo."order/creditcard/ccvm2_enc_card_test.php";
					$url_main=$mainURLpaygo."order/creditcard/ccvm2_enc.php";

				}else{

					$url_main=$mainURLpaygo."order/creditcard/cc_form_enc.php";
				}



				if($this->paygo_load_design2=='yes'){
					$additionalparam_design="&design2=1";

				}else{
					$additionalparam_design="";
				}


				$zipcode = preg_replace('/\s+/', '', $order_billing_postcode);

				$pburl="&pburl=".get_option("siteurl")."/wp-content/plugins/secure_plugin/paygo_postback.php";
				//if($this->tocomplete !=""){ $tocomplete="&tcomplete=".$this->tocomplete."?key=".$order_key."?order_id=".$order_id;}
				//if($this->tocomplete !=""){ $tocomplete="&tcomplete=".$this->tocomplete."/".$order_id."/?key=".$order_key;}

				if($this->tocomplete !=""){ $tocomplete="&tcomplete=".$this->tocomplete;}

				$billing_param="&address=".urlencode($address)."&city=".urlencode($order_billing_city)."&state=".urlencode($order_billing_state)."&zip=".urlencode($zipcode)."&country=".urlencode($order_billing_country);


				$paygoitems_param=$url_main."?site_id=".urlencode($this->siteid)."&trans=".$count_orders."&charge_amount=".urlencode($order->total).$additionalparam_design."&type=purchase&order_description=".urlencode($paygoitems)."&order_key=".$order_key."&woocomerce=1&encrypt=1&session=".urlencode($order_id).$billing_param.$additionalparam.$name_email_param.$shipped.$pburl.$tocomplete;

				
	 
				//$paygourl =$url_main."?site_id=".urlencode($this->siteid)."&charge_amount=".urlencode($order->total).$additionalparam_design."&type=purchase&order_description=".urlencode($paygoitems)."&order_key=".$order_key."&woocomerce=1&encrypt=1&session=".urlencode($order_id).$billing_param.$additionalparam.$name_email_param.$shipped.$pburl.$tocomplete;
			
				$paygourl =$url_main."?param=".encrypt($paygoitems_param,$encryption_key);	
				//wc_add_notice(  "<textarea id='paygo_returl' style='display:none;'>".$paygourl."</textarea>",'success' );
			
	
				//$order = wc_get_order( $order_id );
			
				// Mark as on-hold (we're awaiting the payment)
				$order->update_status( 'pending', __( 'Pending', 'wc-gateway-paygo' ) );
				
				// Reduce stock levels
				$order->reduce_order_stock();

				// Remove cart
				WC()->cart->empty_cart();

				// Return thankyou redirect
				return array(
					'result' 	=> 'success',
					//'redirect'	=> $this->get_return_url( $order )
					'redirect'	=>$paygourl
				); 

		}
	
  } // end WC_Gateway_Paygo class
}


/**
 * Update daily transaction total when Digipay order status changes to processing/completed
 */
add_action( 'woocommerce_order_status_changed', 'digipay_update_daily_total_on_status_change', 10, 4 );
function digipay_update_daily_total_on_status_change( $order_id, $old_status, $new_status, $order ) {
	// Only process for our gateway
	if ( $order->get_payment_method() !== 'paygobillingcc' ) {
		return;
	}

	// Only count when moving TO processing or completed FROM a non-counted status
	$counted_statuses = array( 'processing', 'completed' );
	$was_counted = in_array( $old_status, $counted_statuses );
	$is_counted = in_array( $new_status, $counted_statuses );

	// If transitioning into a counted status from a non-counted status
	if ( $is_counted && ! $was_counted ) {
		$gateway = new WC_Gateway_Paygo_npaygo();
		$gateway->update_daily_transaction_total( $order->get_total() );
	}
}


/**
 * Add admin notice when daily limit is reached
 */
add_action( 'admin_notices', 'digipay_daily_limit_admin_notice' );
function digipay_daily_limit_admin_notice() {
	// Only show on WooCommerce settings pages
	$screen = get_current_screen();
	if ( ! $screen || strpos( $screen->id, 'woocommerce' ) === false ) {
		return;
	}

	$gateway = new WC_Gateway_Paygo_npaygo();
	$daily_limit = floatval( $gateway->daily_limit );
	
	if ( $daily_limit <= 0 ) {
		return;
	}

	$daily_total = $gateway->get_daily_transaction_total();
	$remaining = $gateway->get_remaining_daily_limit();

	if ( $daily_total >= $daily_limit ) {
		echo '<div class="notice notice-warning"><p><strong>Digipay Gateway:</strong> Daily transaction limit of ' . wc_price( $daily_limit ) . ' has been reached. The gateway is currently disabled and will reset at midnight.</p></div>';
	} elseif ( $remaining !== null && $remaining < ( $daily_limit * 0.1 ) ) {
		// Warn when less than 10% remaining
		echo '<div class="notice notice-info"><p><strong>Digipay Gateway:</strong> Daily limit is almost reached. ' . wc_price( $remaining ) . ' remaining of ' . wc_price( $daily_limit ) . ' daily limit.</p></div>';
	}
}


/**
 * Add daily usage stats to gateway settings page (read-only display of remote limits)
 */
add_action( 'woocommerce_settings_checkout', 'digipay_display_daily_stats' );
function digipay_display_daily_stats() {
	if ( isset( $_GET['section'] ) && $_GET['section'] === 'paygobillingcc' ) {
		$gateway = new WC_Gateway_Paygo_npaygo();
		
		// Force refresh if requested
		if ( isset( $_GET['refresh_limits'] ) && $_GET['refresh_limits'] === '1' ) {
			$gateway->refresh_remote_limits();
			// Redirect to remove the query param
			wp_safe_redirect( remove_query_arg( 'refresh_limits' ) );
			exit;
		}
		
		$remote_limits = $gateway->get_remote_limits();
		$daily_limit = floatval( $remote_limits['daily_limit'] );
		$max_ticket = floatval( $remote_limits['max_ticket_size'] );
		$last_updated = $remote_limits['last_updated'];
		$status = $remote_limits['status'] ?? 'unknown';
		$daily_total = $gateway->get_daily_transaction_total();
		
		// Transaction Limits Section (Read-Only)
		echo '<div style="background: #fff; border: 1px solid #ccd0d4; border-left: 4px solid #0073aa; padding: 15px 20px; margin: 20px 0; box-shadow: 0 1px 1px rgba(0,0,0,.04);">';
		echo '<h3 style="margin-top: 0; display: flex; align-items: center; gap: 10px;">';
		echo '<span>Transaction Limits</span>';
		echo '<span style="background: #f0f0f1; color: #50575e; font-size: 11px; font-weight: normal; padding: 2px 8px; border-radius: 3px;">Controlled by Digipay</span>';
		echo '</h3>';
		
		echo '<table class="form-table" style="margin: 0;">';
		
		// Daily Limit (Read-Only)
		echo '<tr>';
		echo '<th scope="row" style="padding: 10px 0;">Daily Transaction Limit</th>';
		echo '<td style="padding: 10px 0;">';
		if ( $daily_limit > 0 ) {
			echo '<span style="font-size: 16px; font-weight: 600;">' . wc_price( $daily_limit ) . '</span>';
		} else {
			echo '<span style="color: #50575e;">No limit set</span>';
		}
		echo '</td>';
		echo '</tr>';
		
		// Max Ticket Size (Read-Only)
		echo '<tr>';
		echo '<th scope="row" style="padding: 10px 0;">Maximum Order Amount</th>';
		echo '<td style="padding: 10px 0;">';
		if ( $max_ticket > 0 ) {
			echo '<span style="font-size: 16px; font-weight: 600;">' . wc_price( $max_ticket ) . '</span>';
		} else {
			echo '<span style="color: #50575e;">No limit set</span>';
		}
		echo '</td>';
		echo '</tr>';
		
		// Last Updated
		echo '<tr>';
		echo '<th scope="row" style="padding: 10px 0;">Last Synced</th>';
		echo '<td style="padding: 10px 0;">';
		if ( $last_updated ) {
			echo '<span style="color: #50575e;">' . esc_html( $last_updated ) . '</span>';
		} else {
			echo '<span style="color: #d63638;">Not synced yet</span>';
		}
		$refresh_url = add_query_arg( 'refresh_limits', '1' );
		echo ' <a href="' . esc_url( $refresh_url ) . '" class="button button-small" style="margin-left: 10px;">Refresh Now</a>';
		echo '</td>';
		echo '</tr>';
		
		echo '</table>';
		
		echo '<p style="color: #646970; font-size: 12px; margin: 15px 0 0 0;">These limits are managed by your payment provider. Contact Digipay support to request changes.</p>';
		echo '</div>';
		
		// Today's Stats Section
		echo '<div style="background: #f8f8f8; border-left: 4px solid #00a32a; padding: 12px 15px; margin: 20px 0;">';
		echo '<h3 style="margin-top: 0;">Today\'s Transaction Stats</h3>';
		echo '<p><strong>Total Processed Today:</strong> ' . wc_price( $daily_total ) . '</p>';
		
		if ( $daily_limit > 0 ) {
			$remaining = max( 0, $daily_limit - $daily_total );
			$percentage = min( 100, ( $daily_total / $daily_limit ) * 100 );
			$bar_color = $percentage >= 100 ? '#dc3232' : ( $percentage >= 90 ? '#ffb900' : '#00a32a' );
			
			echo '<p><strong>Remaining Today:</strong> ' . wc_price( $remaining ) . '</p>';
			echo '<div style="background: #ddd; border-radius: 3px; height: 20px; width: 100%; max-width: 300px;">';
			echo '<div style="background: ' . $bar_color . '; height: 100%; width: ' . $percentage . '%; border-radius: 3px; transition: width 0.3s;"></div>';
			echo '</div>';
			echo '<p style="color: #666; font-size: 12px;">' . round( $percentage, 1 ) . '% of daily limit used</p>';
			
			if ( $percentage >= 100 ) {
				echo '<p style="color: #dc3232;"><strong>⚠ Gateway is currently DISABLED (daily limit reached)</strong></p>';
			}
		}
		
		echo '</div>';
	}
}




//require_once("inc/shippingpost_debitway.php");


/**
* Handle filters for excluding woocommerce statuses from All orders view
*
* @param array $query_vars Query vars.
* @return array
*/
function ts_woocommerce_exclude_order_status( $query_vars ) {
global $typenow,$pagenow;
$_GET['exclude_status']='wc-pending';
/**
* Using wc_get_order_types() instead of 'shop_order' as other order types could be added by other plugins
*/
if ( @$_GET['post_status']=="" ){
	if ( in_array( $typenow, wc_get_order_types( 'order-meta-boxes' ), true ) ) {
		if ( isset( $_GET['exclude_status'] ) && '' != $_GET['exclude_status']
		&& isset( $query_vars['post_status'] ) ) {
			$exclude_status = explode( ',', $_GET['exclude_status'] );
			foreach ( $exclude_status as $key => $value ) {
				if ( ( $key = array_search( $value, $query_vars['post_status'] ) ) !== false) {
				unset( $query_vars['post_status'][$key] );
				}
			}
		}
	}
}
return $query_vars;
}
add_filter( 'request', 'ts_woocommerce_exclude_order_status', 20, 1 );




add_filter( 'woocommerce_can_reduce_order_stock', 'wcs_do_not_reduce_onhold_stock', 10, 2 );
function wcs_do_not_reduce_onhold_stock( $reduce_stock, $order ) {
    if ( $order->has_status( 'pending' ) && ($order->get_payment_method() == 'bacs' || $order->get_payment_method() == 'paygobillingcc') ) {
        $reduce_stock = false;
    }
    return $reduce_stock;
}

add_action( 'woocommerce_order_status_changed', 'order_stock_reduction_based_on_status', 20, 4 );
function order_stock_reduction_based_on_status( $order_id, $old_status, $new_status, $order ){
    // Only for 'processing' and 'completed' order statuses change
    if ( $new_status == 'processing' || $new_status == 'completed' ){
    $stock_reduced = get_post_meta( $order_id, '_order_stock_reduced', true );
        if( empty($stock_reduced) && ($order->get_payment_method() == 'bacs' || $order->get_payment_method() == 'paygobillingcc') ){
            wc_reduce_stock_levels($order_id);
        }
    }
}


/* check woocommerce plugin and if version >= 8.3  implemented blocked type checkout page compatible - added 2024 feb 28 */

add_action('plugins_loaded', 'check_for_woocommerce');
function check_for_woocommerce() {
    if (!defined('WC_VERSION')) {
        // no woocommerce :(
    } else {
        //var_dump("WooCommerce installed in version", WC_VERSION);

    	if (version_compare(WC_VERSION, '8.3', '>=')){
                // 'new version code';

					/* Custom function to declare compatibility with cart_checkout_blocks feature */
					function declare_cart_checkout_blocks_compatibility_paygocc() {
					    // Check if the required class exists
					    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
					        // Declare compatibility for 'cart_checkout_blocks'
					        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
					    }
					}
					// Hook the custom function to the 'before_woocommerce_init' action
					add_action('before_woocommerce_init', 'declare_cart_checkout_blocks_compatibility_paygocc');

					// Hook the custom function to the 'woocommerce_blocks_loaded' action
					add_action( 'woocommerce_blocks_loaded', 'oawoo_register_order_approval_payment_method_type_paygocc' );

					/**
					 * Custom function to register a payment method type

					 */
					function oawoo_register_order_approval_payment_method_type_paygocc() {
					    // Check if the required class exists
					    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
					        return;
					    }

					    // Include the custom Blocks Checkout class
					    require_once plugin_dir_path(__FILE__) . 'class-block.php';

					    // Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
					    add_action(
					        'woocommerce_blocks_payment_method_type_registration',
					        function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
					            // Register an instance of My_paygo_Gateway_Blocks
					            $payment_method_registry->register( new paygo_Gateway_Blocks );
					        }
					    );
					}

	    } else {
	       //  ' old version code1';
	    }


    }
}

/*
if( !function_exists('get_plugin_data') ){
    require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}
 $plugin_dir = WP_PLUGIN_DIR . '/woocommerce/woocommerce.php';

$plugin_data = get_plugin_data($plugin_dir);


if ($plugin_data['Version'] >='8.3' ) {
       // echo 'new version code';
    } else {
        //echo ' old version code';
    }
  */ 