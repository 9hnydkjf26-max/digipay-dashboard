<?php
require_once("../../../wp-load.php");
// Debug: Log ALL incoming requests
file_put_contents(__DIR__ . '/postback_debug.txt', 
    "=== " . date('Y-m-d H:i:s') . " ===\n" .
    "REQUEST: " . print_r($_REQUEST, true) . "\n\n", 
    FILE_APPEND);


//var_dump($_REQUEST);exit;

$order_id=@$_REQUEST['session'];
$upload_dir = wp_get_upload_dir()['basedir'];

$status_post=@$_REQUEST['status_post'];
$transid=@$_REQUEST['transid'];

if($transid!=""){
  update_post_meta($order_id, '_paygo_cc_transaction_id', $transid);  
}

if($status_post!=""){
  update_post_meta($order_id, '_paygo_cc_transaction_status', $status_post);  
}


if($status_post!="" && $status_post=='denied'){
    // Track denied postback (this is expected behavior, not an error)
    if ( function_exists( 'digipay_track_postback' ) ) {
        digipay_track_postback( true ); // Postback received successfully, payment was denied
    }
    exit;
}

//update_post_meta(order_id,'_paygo_cc_authorization_ref', $_POST['authorization_ref']);

/*
if($_SERVER['HTTP_USER_AGENT']!=""){
    $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    $blockeddata=array("Date"=>date("Y-m-d H:i:s"),"URL"=>$actual_link);

    file_put_contents($upload_dir .'/log.txt',  print_r($blockeddata, TRUE), FILE_APPEND);
    echo '<h2>Forbidden1</h2>';

    die();

}*/


function blockBadBots() {
    
    $upload_dir = wp_get_upload_dir()['basedir'];
    $bad_agents = [
        "BadBot", "EvilScraper", "FakeGoogleBot", "SQLmap", "curl", "wget", "bot", "crawler"
    ];

    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';



    // Block if user-agent is empty or matches known bad bots
    if ( preg_match('/' . implode('|', $bad_agents) . '/i', $user_agent)) {
        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") 
                     . "://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

        $blocked_data = [
            "Date" => date("Y-m-d H:i:s"),
            "IP" => $_SERVER['REMOTE_ADDR'],
            "User-Agent" => $user_agent,
            "URL" => $actual_link
        ];

        // Log only real threats
       // file_put_contents($upload_dir . '/blocked_requests.log', json_encode($blocked_data) . PHP_EOL, FILE_APPEND);
        file_put_contents($upload_dir .'/log.txt',  print_r($blockeddata, TRUE), FILE_APPEND);

        // Show a proper forbidden message
        header("HTTP/1.1 403 Forbidden");
        echo "<h2>403 - Forbidden</h2><p>Your request has been blocked.</p>";
        exit();
    }
}

// Call the function at the start of your script
blockBadBots();


if(@$_SERVER['HTTP_REFERER']!="" && (@$_SERVER['HTTP_REFERER']!="https://secure.cptpayments.com/" || @$_SERVER['HTTP_REFERER']!="https://payments.paygobilling.com/")){

$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    $blockeddata=array("Date"=>date("Y-m-d H:i:s"),"URL"=>$actual_link,"Referral"=>$_SERVER['HTTP_REFERER']);

    file_put_contents(getcwd().'/log.txt',  print_r($blockeddata, TRUE), FILE_APPEND);
    echo '<h2>Unauthorized access</h2>';

    die();

}


function wh_log($log_msg) {
     $cwd= $upload_dir = wp_get_upload_dir()['basedir'];

    //$log_filename = $_SERVER['DOCUMENT_ROOT']."/log";
     $log_filename =$cwd."/log";
    if (!file_exists($log_filename))
    {
        // create directory/folder uploads.
        mkdir($log_filename, 0777, true);
    }
     $log_file_data = $log_filename.'/log_' . date('d-M-Y') . '.log';
    file_put_contents($log_file_data, $log_msg . "\n", FILE_APPEND);
}

$logmessage="ses2=".$_REQUEST['session']."ses1=".$_GET['session']."! session=".@$_REQUEST['session']." | custom=".@$_REQUEST['custom']." | state=".@$_REQUEST['shipping_state_or_province']." | transaction_id=".@$_REQUEST['transid']." | status_post=".@$_REQUEST['status_post'];

//wh_log($logmessage);


//$order_paygo = wc_get_order( $order_id );
//var_dump($order_paygo);
//$order = new WC_Order( $order_id );


$order = null;

// Ensure $order_id is a valid integer
if ( ! empty( $order_id ) && is_numeric( $order_id ) ) {
    $order = wc_get_order( (int) $order_id );
}

if ( ! $order ) {
    // Log the issue for debugging (optional)
    //error_log("Order ID {$order_id} does not exist.");

    // Track postback failure
    if ( function_exists( 'digipay_track_postback' ) ) {
        digipay_track_postback( false, 'Order ID ' . $order_id . ' does not exist or is invalid' );
    }

    // Show a user-friendly message instead of a fatal error
    echo "<p style='color: red;'>Sorry, the order does not exist or is invalid.</p>";
    return; // Stop execution
}


$order->get_shipping_methods();
$shipping_option= $order->get_shipping_method();


if(trim($shipping_option)=='In Person'){
    $order->update_status( 'processing' );
}else{
    $order->update_status( 'processing' );
}

// Track successful postback
if ( function_exists( 'digipay_track_postback' ) ) {
    digipay_track_postback( true );
}

 $paygoSettings = get_option( 'woocommerce_paygobilling_settings');
 //var_dump( $paygoSettings );
//$paygoSettings = unserialize(get_option( 'woocommerce_paygobilling_settings'));
$description= $paygoSettings['description'];

 $order_key =$order->get_order_key( $context );

$url=get_option('siteurl')."/checkout/order-received/".$order_id."/?key=". $order_key;
//header("Location: ".$url);
    
?>
<rsp stat="ok" version="1.0">
<message id="100"></message>
<receipt>324342323</receipt>
</rsp>